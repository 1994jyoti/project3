<?php
include("connection.php");
$date = mysqli_real_escape_string($conn, $_REQUEST['date']);
$time = mysqli_real_escape_string($conn,$_REQUEST['time']);
 
// attempt insert query execution
$sql = "INSERT INTO table_reserve (date, time) VALUES ('$date', '$time')";
if(mysqli_query($conn, $sql)){
 echo "<script>
window.location.href='in.php';
alert('thank you, your table is reserved');
</script>";}
		
// close connection
mysqli_close($conn);
?>
