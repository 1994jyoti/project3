<?php
   include("connection.php");
   session_start();
      {
      $email = mysqli_real_escape_string($conn,$_POST['email']);
      $password = mysqli_real_escape_string($conn,$_POST['password']); 
        $sql = "SELECT email,password FROM signup WHERE email = '$email' and password = '$password'";
      $result = mysqli_query($conn,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      $active = $row['active'];
      
      $count = mysqli_num_rows($result);	
      if($count == 1) {
        
         $_SESSION['email'] = $email;
         header("location: in.php");
      }else {
         $error = "Your Login Name or Password is invalid";
          echo $error;
header("location: register.html");
      }
   }
?>