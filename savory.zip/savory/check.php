<?php
	// include Database connection file 
	include("connection.php");

	$email = mysqli_real_escape_string($conn, $_POST['email']);

	$query = "SELECT email FROM signup WHERE email = '$email'";
	if(!$result = mysqli_query($conn, $query))
	{
		exit(mysqli_error($conn));
	}

	if(mysqli_num_rows($result) > 0)
	{
		// username is already exist 
		echo "<script>
window.location.href='register.html';
alert('try some different username');
</script>";
	}
	else
	{
	
$name = mysqli_real_escape_string($conn,$_REQUEST['name']);
$email = mysqli_real_escape_string($conn, $_REQUEST['email']);
$password = mysqli_real_escape_string($conn,$_REQUEST['password']);
 
// attempt insert query execution
$sql = "INSERT INTO signup (name,email,password) VALUES ('$name', '$email', '$password')";
if(mysqli_query($conn, $sql)){
   include("in.php");
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
}
 
// close connection
mysqli_close($conn);

	}

?>