<?php
    include("connection.php");
$name = mysqli_real_escape_string($conn, $_REQUEST['name']);
$email = mysqli_real_escape_string($conn,$_REQUEST['email']);
 $notification = mysqli_real_escape_string($conn,$_REQUEST['notification']);
// attempt insert query execution
$sql = "INSERT INTO contact (name, email , notification) VALUES ('$name', '$email' , '$notification')";
if(mysqli_query($conn, $sql)){
 echo "<script>
window.location.href='in.php';
alert('thank you');
</script>";}		
// close connection
mysqli_close($conn);

?>
